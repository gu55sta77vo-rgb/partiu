# PARTIU — versão final para publicação

Plataforma de venda de ingressos com ADM, organizador, eventos, foto, estoque, pedidos e PIX automático via Mercado Pago.

## Login inicial
- ADM: `adm`
- Senha inicial: `1234`

Troque a senha no ambiente de produção antes de divulgar o sistema.

## Mercado Pago
Configure no servidor:
- `MP_ACCESS_TOKEN`
- `MP_WEBHOOK_SECRET`
- `PUBLIC_URL` (HTTPS)

Webhook:
`https://SEU-ENDERECO/api/webhooks/mercadopago`

O PARTIU cria o pagamento PIX pela API, mostra QR Code/Copia e Cola e aguarda o webhook. Quando o Mercado Pago informa pagamento aprovado, o pedido é marcado como CONFIRMADO e o ingresso recebe um código/QR de entrada.

## Render
Use o `render.yaml` ou crie um Web Service Node. O sistema grava banco JSON e uploads em `/var/data`, que deve estar em disco persistente. O Render informa que o filesystem padrão é efêmero e que um persistent disk preserva os arquivos entre deploys/restarts.

## Local
```bash
npm ci
npm start
```
Abra `http://localhost:3000`.
