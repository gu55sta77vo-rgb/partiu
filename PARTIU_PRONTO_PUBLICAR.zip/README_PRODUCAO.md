# PARTIU — versão de produção

## O que já está preparado
- Login real por sessão segura em cookie HTTP-only.
- ADM e Organizador separados por permissão.
- Senhas armazenadas com hash.
- Limite de tentativas de login.
- Headers de segurança.
- Eventos com foto, preço e estoque.
- Organizador vinculado a um evento.
- Compra e pedido persistentes.
- QR Code PIX e PIX copia e cola.
- Confirmação de pagamento pelo ADM.
- Ingresso liberado depois da confirmação.
- Uploads e dados em diretório persistente.
- `Dockerfile` e `render.yaml` incluídos.
- Health check em `/api/health`.

## Login inicial
Usuário: `adm`
Senha: `1234`

Troque a senha antes de divulgar o sistema. A variável `ADMIN_PASSWORD` só é usada para criar o ADM inicial quando ainda não existe banco.

## Publicação
### Opção com Docker
```bash
docker build -t partiu .
docker run -p 3000:3000   -e NODE_ENV=production   -e SESSION_SECRET="UMA_CHAVE_LONGA_E_ALEATORIA"   -e ADMIN_PASSWORD="SUA_SENHA"   -e PIX_KEY="91989935507"   -v partiu-data:/app/data   partiu
```

### Opção Node.js
```bash
npm ci
npm start
```
Configure as variáveis do `.env.example` no painel da hospedagem.

### Render
O `render.yaml` já está incluído. Ele cria o serviço, health check e disco persistente. No painel, defina `ADMIN_PASSWORD` e depois faça o deploy.

## Importante sobre PIX
O sistema gera o QR Code e o copia-e-cola usando a chave configurada e deixa o pedido como PENDENTE. A confirmação do pagamento continua sendo feita pelo ADM.

Para confirmação automática do PIX, ainda é necessário conectar um provedor/banco que ofereça API PIX e webhook. Não invente confirmação apenas porque o QR Code foi gerado.

## Dados
A versão usa armazenamento JSON persistente. Para uma operação muito grande ou múltiplas instâncias, recomenda-se migrar o armazenamento para PostgreSQL.
